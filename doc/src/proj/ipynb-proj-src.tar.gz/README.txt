This IPython notebook proj.ipynb does not require any additional
programs.
