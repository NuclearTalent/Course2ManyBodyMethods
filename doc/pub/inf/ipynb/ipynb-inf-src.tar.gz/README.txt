This IPython notebook inf.ipynb does not require any additional
programs.
