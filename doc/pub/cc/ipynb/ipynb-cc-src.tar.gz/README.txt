This IPython notebook cc.ipynb does not require any additional
programs.
